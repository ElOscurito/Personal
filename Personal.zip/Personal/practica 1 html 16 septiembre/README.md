# Pagina-Web
titulo del proyecto: venta de respuestos automotrices
integrantes: borys jared macias lucas, leandro jesus veliz ponce, Dayana Liseth Anchundia García
descripcion: la pagina web tendra como fin vender productos del apartado automotriz, estos contaran con su respectiva descripcion e imagen de referencia dividida por categorias
arquitectura del sitio:
- pagina principal
- catalgos de productos  
intrucciones de uso: 
1. igresar a la sitio web
2. usar el buscador
3. dividir por categoria
4. selecionar el producto
5. realizar compra
